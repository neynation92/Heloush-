HELOUSH CROCHET — VERSION À DÉPLOYER

Fichiers:
- index.html : boutique client
- admin.html : espace administrateur
- supabase.js : connexion Supabase
- category-*.svg : visuels des catégories

IMPORTANT:
1. Le SQL Supabase a déjà été exécuté dans le projet.
2. Créer l'utilisateur Admin dans Supabase Authentication.
3. Ajouter son UUID dans public.admins.
4. Le logo réel doit être placé sous le nom logo.jpg à côté de index.html et admin.html.
5. Aucun compte client n'est nécessaire.
6. Les commandes et inscriptions passent par WhatsApp 93 78 83 12.

Identifiants prévus:
- utilisateur: admin
- mot de passe: helous93

Pour un déploiement public, garder la clé Supabase publishable côté client et s'appuyer sur les policies RLS.
